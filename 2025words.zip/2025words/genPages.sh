#!/bin/bash
cd January
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'January' 1 31
cd ../February
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'February' 1 28
cd ../March
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'March' 1 31
cd ../April
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'April' 1 30
cd ../May
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'May' 1 31
cd ../June
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'June' 1 30
cd ../July
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'July' 1 31
cd ../July
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'July' 1 31
cd ../August
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'August' 1 31
cd ../September
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'September' 1 30
cd ../October
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'October' 1 31
cd ../November
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'November' 1 30
cd ../December
/opt/local/bin/python3.12 ../makeDaily750PagesVerC.py 2025 'December' 1 31
